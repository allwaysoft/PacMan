﻿namespace PacMan.SoundProvider.SoundPlayers
{
    public interface ISoundPlayer
    {
        void Play();

        void Pause();
    }
}
