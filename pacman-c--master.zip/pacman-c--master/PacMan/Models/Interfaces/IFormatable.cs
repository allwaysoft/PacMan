﻿namespace PacMan.Models.Interfaces
{
    using System.Windows.Controls;

    public interface IFormatable
    {
        TextBlock Format();
    }
}